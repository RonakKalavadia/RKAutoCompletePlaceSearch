//
//  RKAutoCompleteVC.swift
//  RKAutocompletePlaceSearch
//
//  Created by Ronak Kalavadia on 23/03/16.
//  Copyright © 2016 Ronak Kalavadia. All rights reserved.
//

import UIKit
import GoogleMaps

class RKAutoCompleteVC: UIViewController,UISearchBarDelegate , LocateOnTheMap {

    @IBOutlet weak var viewGoogleMap: UIView!
    var googleMapsView: GMSMapView!
    var searchResultController: SearchResultsController!
    var placeArray = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(animated: Bool) {
        self.googleMapsView = GMSMapView(frame: self.viewGoogleMap.frame)
        self.view.addSubview(self.googleMapsView)
        
        searchResultController = SearchResultsController()
        searchResultController.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // Search Button Action Event
    
    @IBAction func btnSearch(sender: AnyObject) {
       
        let searchController = UISearchController(searchResultsController: searchResultController)
        searchController.searchBar.delegate = self
        self.presentViewController(searchController, animated: true, completion: nil)
        
    }
    
    
    
    // Here you got CLLocationCoordinate
    
    func locateWithLongitude(lon: Double, andLatitude lat: Double, andTitle title: String) {
        
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            
            let position = CLLocationCoordinate2DMake(lat, lon)
            let marker = GMSMarker(position: position)
            
            let camera = GMSCameraPosition.cameraWithLatitude(lat, longitude: lon, zoom: 10)
            self.googleMapsView.camera = camera
            
            marker.title = "Address : \(title)"
            marker.map = self.googleMapsView
            
            
            print("YAHOOOOO....got Latitude & Longitude!! \n\n Latitude :: \(lat) \n Longitude :: \(lon)")
            
            
        }
        
    }

    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        let placeClient = GMSPlacesClient()
        placeClient.autocompleteQuery(searchText, bounds: nil, filter: nil) { (results, error: NSError?) -> Void in
            
            self.placeArray.removeAll()
            if results == nil {
                return
            }
            
            for result in results! {
                if let result = result as? GMSAutocompletePrediction {
                    self.placeArray.append(result.attributedFullText.string)
                }
            }
            
            self.searchResultController.reloadDataWithArray(self.placeArray)
            
        }
    }


}
